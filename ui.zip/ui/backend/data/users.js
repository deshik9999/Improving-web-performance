
const users = [
  {
    name: 'Admin User',
    email: 'admin@example.com',
    password: "$2a$10$/O.YVp9Bw9zsRYpabZyt3uh7SH5FYGF/8ZOA8WeSeTBN6sswK6K8a", // 123456
    isAdmin: true,
  }
]

export default users